package com.example.portales.multivistas_alejandrosaenz29;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity {
Button siguiente;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        siguiente = (Button)findViewById(R.id.button2);
        siguiente.setOnClickListener (new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent siguiente = new Intent(Main2Activity.this, MainActivity.class);
                startActivity(siguiente);
            }

        });
    }
}
